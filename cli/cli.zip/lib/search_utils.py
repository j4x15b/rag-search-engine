import json
from pathlib import Path
from functools import lru_cache
import string

# output movie count
DEFAULT_SEARCH_LIMIT = 5
DEFAULT_TEXT_LENGTH = 200
FULL_TEXT_LENGTH = None


# BM25_TFIDF constants
BM25_K1 = 1.5
BM25_B = 0.75

#setting data_paths
project_root = Path(__file__).parent.parent.parent
cache_path = project_root / "cache"
movie_data_path = project_root / "data" / "movies.json"
stopwords_data_path = project_root / "data" / "stopwords.txt"


#creating subpath

def create_subfolder(folder_name: str) -> bool:
    target = project_root / folder_name
    if target.exists():
        print("Folder already existing")
        return True
    else:
        print(f"creating folder: {folder_name}")
        target.mkdir(parents=True)
        return False

# load  movie data base
@lru_cache(maxsize=None)
def load_movies() -> list[dict]:
    with open(movie_data_path, 'r', encoding='utf-8') as file:
        movie_data = json.load(file)
    return movie_data["movies"]

@lru_cache(maxsize=None)
def load_stopwords(): # -> set(str)
    with open(stopwords_data_path, 'r', encoding='utf-8') as file:
        #stopword_set = frozenset(line.strip() for line in file)
        stopword_set = frozenset(line.strip().lower().translate(str.maketrans("", "", string.punctuation)) for line in file)
        #returns lowered, stripped stopwords with removed punctuation
    return stopword_set

# formatting search results

def format_search_result(result, document_map):
    #formatted_result = format_search_result(result, self.document_map, self.chunk_metadata)    
    
    result_list = []
    #print(self.chunk_metadata)
    for key, value in result.items():
        result_list.append(
        #full_result_dict[key] = {
        {
            "id": key,
            "title": document_map[key]["title"],
            "document": document_map[key]["description"][:100],
            "score": round(value, 4) #"score": round(value, SCORE_PRECISION),
            #"metadata":  ???
        })
 
    return result_list
